package wikipediaTest.runners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		plugin = {
				//"pretty",
				"html:target/default-cucumber-reports"
				,"json:target/cucumber.json"
		},
		
		tags= "@temp",	// if I put login in the login page file and here as a tags it execute only 3 steps in login page
	features = "resources/wikipediaTest/features/",	
	glue= "wikipediaTest/step_definitions"
	 
	,dryRun= false
	
		)

public class CukesRunner {

	 
	
	
	
	
	
}
